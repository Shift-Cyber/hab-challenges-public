export HAB_CONTROLLER=flag{Controller}
export HAB_COREDUMP=flag{coredump}
export HAB_BITSANDBYTES=flag{bitsandbytes}

./corruption